package kw.listviewdemo;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ListView listView;
    TextView tvSelect;

    String[] Datalist = {"apple", "banana", "lemon", "mango", "orange", "melon", "pineapple", "watermelon"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        listView = findViewById(R.id.listView);
        tvSelect = findViewById(R.id.tvSelect);

        ArrayAdapter<String> adapterData
                = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, Datalist);
        listView.setAdapter(adapterData);

        listView.setOnItemClickListener(demo);
    }

    ListView.OnItemClickListener demo = new ListView.OnItemClickListener() {
        @Override
        public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
            String selectText = parent.getItemAtPosition(position).toString();
            tvSelect.setText( tvSelect.getText().toString() + " " + selectText);
        }
    };

    public void reset(View v) {
        tvSelect.setText(getString(R.string.lv_select));
    }

}
