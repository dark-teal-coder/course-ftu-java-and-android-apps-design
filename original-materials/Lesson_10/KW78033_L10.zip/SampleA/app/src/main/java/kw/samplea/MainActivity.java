package kw.samplea;

import android.os.Bundle;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout ll = new LinearLayout(this);
        ll.setOrientation(LinearLayout.VERTICAL);

        setContentView(ll);

        TextView tv = new TextView(this);
        tv.setText("Anroid 1234");

        Button bt = new Button(this);
        bt.setText("KO");


        ll.addView(tv);
        ll.addView(bt);





    }
}
