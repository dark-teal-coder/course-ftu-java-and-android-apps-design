package kw.memberinfo;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText etName, etPasswd;
    RadioButton rbMale, rbFemale, rbGold, rbSilver, rbCopper;
    Spinner spAddr;
    CheckBox cbGTAct, cbGTAdv, cbGTSim, cbGTSpt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etName = findViewById(R.id.etName);
        etPasswd = findViewById(R.id.etPasswd);
        rbMale = findViewById(R.id.rbMale);
        rbFemale = findViewById(R.id.rbFemale);
        rbGold = findViewById(R.id.rbGold);
        rbSilver = findViewById(R.id.rbSilver);
        rbCopper = findViewById(R.id.rbCopper);
        spAddr = findViewById(R.id.spAddr);

        cbGTAct = findViewById(R.id.cbGTAct);
        cbGTAdv = findViewById(R.id.cbGTAdv);
        cbGTSim = findViewById(R.id.cbGTSim);
        cbGTSpt = findViewById(R.id.cbGTSpt);
    }

    public void createAcc(View v) {
        String Message;

        Message = "User Name: " + etName.getText().toString() + "\n"
                + "Password: " + etPasswd.getText().toString() + "\n";

        if (rbMale.isChecked())
            Message += "Gender: Male\n";
        else
            Message += "Gender: Female\n";

        if (rbGold.isChecked())
            Message += "Member: Gold\n";
        else if (rbSilver.isChecked())
            Message += "Member: Silver\n";
        else
            Message += "Member: Copper\n";

        Message += "Address: " + spAddr.getSelectedItem().toString() + "\n"
                + "Game Type:\n";

        if (cbGTAct.isChecked()) Message += "Action ";
        if (cbGTAdv.isChecked()) Message += "Adventure ";
        if (cbGTSim.isChecked()) Message += "Simulation ";
        if (cbGTSpt.isChecked()) Message += "Sports";


        AlertDialog.Builder adDialog = new AlertDialog.Builder(this);

        adDialog.setTitle("Are You sure?");
        adDialog.setMessage(Message);

        adDialog.setPositiveButton("OK", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                Toast toast = Toast.makeText(getApplicationContext(), "Member created", Toast.LENGTH_SHORT);
                toast.show();

                // go to next screen
            }
        });

        adDialog.setNegativeButton("Change", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                etName.setSelectAllOnFocus(true);
                etName.requestFocus();

            }
        });

        adDialog.show();
    }
}
