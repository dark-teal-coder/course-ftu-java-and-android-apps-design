package com.example.menudemo;

import android.graphics.Color;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    TextView tvTop;
    ImageView ivLeft, ivRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        tvTop = findViewById(R.id.tvTop);
        ivLeft = findViewById(R.id.ivLeft);
        ivRight = findViewById(R.id.ivRight);

        registerForContextMenu(ivLeft);
        registerForContextMenu(ivRight);
        registerForContextMenu(tvTop);
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        getMenuInflater().inflate(R.menu.main, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        int id = item.getItemId();

        if (id == R.id.item1) {
            tvTop.setBackgroundColor(Color.RED);
        } else if (id == R.id.item2) {
            tvTop.setBackgroundColor(Color.GREEN);
        } else if (id == R.id.item3) {
            tvTop.setBackgroundColor(Color.BLUE);
        } else if (id == R.id.item4) {
            tvTop.setBackgroundColor(Color.alpha(0));
        }

        return super.onOptionsItemSelected(item);
    }

    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        if (v == ivLeft){
            menu.add(0, 101, 1, "Blue Hills");
            menu.add(0, 102, 2, "Sunset");
            menu.add(0, 103, 3, "Water Lilies");
            menu.add(0, 104, 4, "Winter");
        } else if (v == ivRight){
            menu.add(0, 201, 2, "Yellow");
            menu.add(0, 202, 1, "Cyan");
            menu.add(0, 203, 3, "Magenta");
        }else if (v == tvTop){
            menu.add(0, 301, 2, "Restore");
        }
    }

    @Override
    public boolean onContextItemSelected(MenuItem item) {
        switch (item.getItemId()){
            case 101:
                ivLeft.setImageResource(R.drawable.bluehills);
                break;
            case 102:
                ivLeft.setImageResource(R.drawable.sunset);
                break;
            case 103:
                ivLeft.setImageResource(R.drawable.waterlilies);
                break;
            case 104:
                ivLeft.setImageResource(R.drawable.winter);
                break;

            case 201:
                tvTop.setBackgroundColor(Color.YELLOW);
                break;
            case 202:
                tvTop.setBackgroundColor(Color.CYAN);
                break;
            case 203:
                tvTop.setBackgroundColor(Color.MAGENTA);
                break;

            case 301:
                ivLeft.setImageResource(R.drawable.waterlilies);
                tvTop.setBackgroundColor(Color.alpha(0));
                break;
        }
        return super.onContextItemSelected(item);
    }


}
