package com.example.drawnumber;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void draw(View v) {
        Button bt = findViewById(R.id.btDraw);

        int drawNum = (int) (Math.random() * 49 + 1);

        bt.setText(String.valueOf(drawNum));

    }

}
