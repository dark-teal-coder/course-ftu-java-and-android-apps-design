package com.example.screenlight;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Switch;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    LinearLayout llScreen;
    Switch swLight;
    SeekBar seekBar, seekBar2, seekBar3;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        llScreen = findViewById(R.id.llScreen);
        swLight = findViewById(R.id.swLight);
        seekBar = findViewById(R.id.seekBar);
        seekBar2 = findViewById(R.id.seekBar2);
        seekBar3 = findViewById(R.id.seekBar3);

        seekBar.setOnSeekBarChangeListener(dragBar);
        seekBar2.setOnSeekBarChangeListener(dragBar);
        seekBar3.setOnSeekBarChangeListener(dragBar);
    }

    SeekBar.OnSeekBarChangeListener dragBar = new SeekBar.OnSeekBarChangeListener() {
        @Override
        public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
            llScreen.setBackgroundColor(Color.rgb(progress, progress, progress));
            setTitle(getString(R.string.app_name) + "  Level: " + progress);
        }

        @Override
        public void onStartTrackingTouch(SeekBar seekBar) {

        }

        @Override
        public void onStopTrackingTouch(SeekBar seekBar) {
            int level = seekBar.getProgress();

            if (level == 0)
                swLight.setChecked(false);
            else
                swLight.setChecked(true);

        }
    };

    public void switchLight(View v) {
        if (swLight.isChecked())
            seekBar.setProgress(255);
        else
            seekBar.setProgress(0);
    }

}