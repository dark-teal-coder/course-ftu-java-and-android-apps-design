package kw.calculator2019;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    EditText etNum1, etNum2;
    RadioButton rbAdd, rbSub, rbTms, rbDiv;
    Button btCalc;
    TextView tvAnswer;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etNum1 = findViewById(R.id.etNum1);
        etNum2 = findViewById(R.id.etNum2);
        rbAdd = findViewById(R.id.rbAdd);
        rbSub = findViewById(R.id.rbSub);
        rbTms = findViewById(R.id.rbTms);
        rbDiv = findViewById(R.id.rbDiv);
        btCalc = findViewById(R.id.btCalc);
        tvAnswer = findViewById(R.id.tvAnswer);

        btCalc.setOnClickListener(clickJob);
        btCalc.setOnLongClickListener(longClickJob);

        rbAdd.setOnClickListener(clickJob);
        rbSub.setOnClickListener(clickJob);
        rbTms.setOnClickListener(clickJob);
        rbDiv.setOnClickListener(clickJob);



    }

    View.OnClickListener clickJob = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            String text1 = etNum1.getText().toString();
            String text2 = etNum2.getText().toString();


            if (text1.equals("") || text2.equals("")) {
                Toast.makeText(getApplicationContext(), "Missing Number", Toast.LENGTH_SHORT).show();
                return;
            }

            double num1 = Double.parseDouble(text1);
            double num2 = Double.parseDouble(text2);

            if (rbAdd.isChecked())
                tvAnswer.setText(String.valueOf(num1 + num2));
            else if (rbSub.isChecked())
                tvAnswer.setText(String.valueOf(num1 - num2));
            else if (rbTms.isChecked())
                tvAnswer.setText(String.valueOf(num1 * num2));
            else if (rbDiv.isChecked())
                tvAnswer.setText(String.valueOf(num1 / num2));
        }
    };

    View.OnLongClickListener longClickJob = new View.OnLongClickListener() {
        @Override
        public boolean onLongClick(View v) {
            etNum1.setText("");
            etNum2.setText("");
            tvAnswer.setText("");

            etNum1.requestFocus();
            return true;
        }
    };



}
