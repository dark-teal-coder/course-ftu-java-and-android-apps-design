package com.example.game888;

import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void onDraw(View v) {
        TextView tvNum1 = findViewById(R.id.tvNum1);
        TextView tvNum2 = findViewById(R.id.tvNum2);
        TextView tvNum3 = findViewById(R.id.tvNum3);

        LinearLayout llPic = findViewById(R.id.llPic);

        int drawNum1 = (int) (Math.random() * 9 + 1);
        int drawNum2 = (int) (Math.random() * 9 + 1);
        int drawNum3 = (int) (Math.random() * 9 + 1);

        tvNum1.setText(String.valueOf(drawNum1));
        tvNum2.setText(String.valueOf(drawNum2));
        tvNum3.setText(String.valueOf(drawNum3));

        if (drawNum1 == 8 || drawNum2 == 8 || drawNum3 == 8)
            llPic.setBackgroundResource(R.drawable.sunset);
        else
            llPic.setBackgroundColor(Color.rgb(52, 225, 235));
    }
}
