package kw.letsix;

import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    int num = 4;
    TextView[] tvNum = new TextView[num];

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        LinearLayout llNumList = findViewById(R.id.llNumList);
        String colorText;

        for (int i=0; i<num; i++){
            tvNum[i] = new TextView(this);

            tvNum[i].setText(Integer.toString((int)(Math.random()*49+1)));
            tvNum[i].setTextSize(36);
            tvNum[i].setGravity(Gravity.CENTER);

            if (i%2 == 0)
                colorText = "#ffcccc";
            else
                colorText = "#ffffcc";

            tvNum[i].setBackgroundColor(Color.parseColor(colorText));

            tvNum[i].setOnClickListener(ckChange);

            LinearLayout.LayoutParams params
                    = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT,
                    1);

            llNumList.addView(tvNum[i], params);
        }
    }

    View.OnClickListener ckChange = new View.OnClickListener() {
        public void onClick(View v) {
            TextView tmp = (TextView) v;

            tmp.setText(Integer.toString((int)(Math.random()*49+1)));
        }
    };

    public void clickToSort(View v){
        int[] data = new int[num];
        int i;

        for (i = 0; i < num; i++)
            data[i] = Integer.parseInt(tvNum[i].getText().toString());

        Arrays.sort(data);

        for (i = 0; i < num; i++)
            tvNum[i].setText(Integer.toString(data[i]));
    }

    public void newSix(View v){
        int i;

        for (i = 0; i < num; i++)
            tvNum[i].setText(Integer.toString((int)(Math.random()*49+1)));
    }

}
