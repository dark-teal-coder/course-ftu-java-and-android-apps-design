package kw.pictureviewer;

import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    ImageView ivPic;
    ImageButton ibLeft, ibRight;
    TextView tvMessage;

    int[] imageId = {R.drawable.bluehills, R.drawable.sunset, R.drawable.waterlilies, R.drawable.winter};
    int pos = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ivPic = findViewById(R.id.ivPic);
        ibLeft = findViewById(R.id.ibLeft);
        ibRight = findViewById(R.id.ibRight);
        tvMessage = findViewById(R.id.tvMessage);
        tvMessage.setText(ivPic.getResources().getResourceEntryName(imageId[pos]));

        ibLeft.setOnClickListener(clickJob);
        ibRight.setOnClickListener(clickJob);
    }

    View.OnClickListener clickJob = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v==ibLeft)
                pos = pos == 0 ? 3 : pos - 1;
            else
                pos = pos == 3 ? 0 : pos + 1;

            ivPic.setImageResource(imageId[pos]);
            tvMessage.setText(ivPic.getResources().getResourceEntryName(imageId[pos]));
        }
    };

}

